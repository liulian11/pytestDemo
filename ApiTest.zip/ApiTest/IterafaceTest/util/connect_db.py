import pymysql

# python3用的是pymysql，python2用的是MySQLdb


class OperationMysql:
    def __init__(self):
        self.conn = pymysql.connect(
            host='10.11.12.194',
            port=3306,
            user='root',
            passwd='123456',
            db='dubhe_dev',
            charset='utf8',
            cursorclass=pymysql.cursors.DictCursor
        )
        self.cur = self.conn.cursor()

    # 查询一条数据
    def search_one(self, sql):
        self.cur.execute(sql)
        result = self.cur.fetchone()
        return result

    # 更新SQL
    def update_one(self, sql):
        self.cur.execute(sql)
        self.conn.commit()
        self.conn.close()


if __name__ == '__main__':
    op_mysql = OperationMysql()
    res = op_mysql.search_one("SELECT * from experiment_flow")
    print(res)
