from dingtalkchatbot.chatbot import DingtalkChatbot
import requests


class SendText:
    def __init__(self):
        # 初始化机器人小钉钉
        self.xiaoding = DingtalkChatbot()

    def send(self,content_link):

        content_text = {
            "msgtype": "text",
            "text": {
                "content": "测试报告出来啦！"
            },
            "atMobiles": ["13228060526"],
            "at": {
                # @ 所有人
                "isAtAll": False
            }
        }

        # content_link = {
        #     "msgtype": "link",
        #     "link": {
        #         "text": "测试报告",
        #         "title": "测试报告",
        #         "messageUrl": "D:/work/自动化测试/ApiTest/IterafaceTest/report/test.html"
        #     }
        # }

        headers = {"Content-Type": "application/json;charset=utf-8"}
        # WebHook地址
        url = 'https://oapi.dingtalk.com/robot/send?access_token=d8b771c75883bec3ab9e77ea8551c893f640f2b54e0cd4238e51d7c2752feafd'

        r = requests.post(url=url, headers=headers, json=content_link)


if __name__ == '__main__':
    print("test")
