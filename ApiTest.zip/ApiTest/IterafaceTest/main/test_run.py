import unittest
#import HTMLTestRunner
from HTMLTestRunner import HTMLTestRunner
import requests
import json
from IterafaceTest.base.runmethod import RunMethod
from IterafaceTest.data.get_data import GetData
from IterafaceTest.util.common_util import CommonUtil
from IterafaceTest.data.dependent_data import DependentData
from IterafaceTest.util.dingtalk import SendText
from IterafaceTest.util.operation_json import OperationJson
from IterafaceTest.util.send_email import SendEmail
from IterafaceTest.util.operation_header import OperationHeader
# from IterafaceTest.util.operation_json import OperationJson


class TestRun(unittest.TestCase):

    def setUp(self):
        self.run_method = RunMethod()
        self.data = GetData()
        self.com_util = CommonUtil()
        self.send_email = SendEmail()
        print("测试开始")

    def test_run(self):
        """程序执行"""
        pass_count = []
        fail_count = []
        res = None
        # 获取用例数
        rows_count = self.data.get_case_lines()
        # 第一行索引为0
        for i in range(1, rows_count):
            is_run = self.data.get_is_run(i)
            if is_run:
                url = self.data.get_request_url(i)
                method = self.data.get_request_method(i)
                request_data = self.data.get_data_for_json(i)
                expect = self.data.get_expect_data(i)
                header = self.data.is_header(i)
                depend_case = self.data.is_depend(i)
                change_sql = self.data.get_sql_data(i)
                try:
                    if depend_case != None:
                        self.depend_data = DependentData(depend_case)
                        # 获取依赖的响应数据
                        depend_response_data = self.depend_data.get_data_for_key(i)
                        # 获取依赖的key
                        depend_key = self.data.get_depend_field(i)
                        # 更新请求字段
                        request_data[depend_key] = depend_response_data
                    # 修改sql
                    if change_sql != None:
                        self.data.update_sql(i)

                    if header == 'yes':
                        header = {
                            'Content-Type': 'application/json'
                        }
                        res = requests.post(url, headers=header, data=json.dumps(request_data))
                    elif header == 'no':
                        url = url + '?' + request_data
                        data = None
                        res = requests.get(url)
                        #res = self.run_method.run_main(method, url, data)
                    else:
                        res = self.run_method.run_main(method, url, request_data)
                except Exception as e:
                    res="运行失败"
                    print(f"第{i}条用例{res},错误原因{e}")

                if expect != None:
                    if self.com_util.is_contain(expect, json.dumps(res.json())):
                        self.data.write_result(i, "Pass")
                        pass_count.append(i)
                        assert True
                    else:
                        self.data.write_result(i, res.json())
                        fail_count.append(i)
                        assert False
                else:
                    print(f"用例ID：case-{i}，预期结果不能为空")

        # 发送邮件
        self.send_email.send_main(pass_count, fail_count)

        print(f"通过用例数：{len(pass_count)}")
        print(f"失败用例数：{len(fail_count)}")


if __name__ == '__main__':
    # 创建测试用例容器
    testlist = unittest.TestSuite()
    # 将用例添加到容器中
    # testlist.addTest(类名("函数名"))
    testlist.addTest(TestRun("test_run"))

    # 创建测试报告
    # 创建文件目录
    file = '../report/test.html'
    fle = open(file, "wb")  # 生成测试报告的时候用的是二进制文件wb    rb wb  以进制的方式进行读写文件
    # 定义测试报告，stream定义报告所写入的内容，title为报告标题，description为报告的说明与描述
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fle,
        title=u"接口测试报告",
        description=u"用例执行情况"
    )
    # 将测试报告和用例容器关联在一起
    runner.run(testlist)
    fle.close()
    content_link = {
        "msgtype": "link",
        "link": {
            "text": "测试报告",
            "title": "测试报告",
            "messageUrl": file
        }
    }
    SendText.send("", content_link)
